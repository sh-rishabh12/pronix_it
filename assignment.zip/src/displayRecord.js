import React from 'react';

const displayRecord = (props) => {

    const data=props.data;
    let empData=null;
    if(data !==null){
     empData= data.map((employee,index)=>(
        <tr>
            <td>{employee.id}</td>
            <td>{employee.employee_name}</td>
            <td>{employee.employee_salary}</td>
            <td>{employee.employee_age}</td>
        </tr>
));
}
    return (

        <div className="container">
            <h3 className="header">Employee Details</h3>
            <table className="table">
            <thead>
                <tr>
                <th>ID</th>
                <th>Employee Name</th>
                <th>Employee Salary</th>
                <th> Employee Age</th>
                </tr>
            </thead>
            <tbody>
                {empData}
            </tbody>

            </table>
            
        </div>
    );
};

export default displayRecord;