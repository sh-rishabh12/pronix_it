import React, { Component } from 'react';
import './App.css';
import axios from 'axios';
import DisplayRecord from './displayRecord';

class App extends Component {

  constructor(props){
    super(props);
    this.state={
      name:'',
      password:'',
      displayData:false,
      data:null,
    }

  }

  nameChange=(event)=>{
    this.setState({username:event.target.value});
  }

  passwordChange=(event)=>{
    this.setState({password:event.target.value});
  }

  submit=()=>{
    if(this.state.username && this.state.password){
    axios.get('http://dummy.restapiexample.com/api/v1/employees')
    .then(response=>{
        this.setState({data:response.data,displayData:true});
    })
    .catch(error=>{
      console.log(error);
    })
  }
  }

  render() { 
    //Display a login form...on entering data and click of submit button display data
    return (
      this.state.displayData ? <DisplayRecord data={this.state.data} />: 
      <div className="container">
      <h2 className="header">Login Form</h2>
      <form>    
      <div className="form-group">    
      <label for="usr"><h6>Name:</h6></label>
          <input type='text' name='username' className="form-control" value={this.state.username} onChange={(event)=>this.nameChange(event)} id='usr' />
          </div>

          <div className="form-group">    
      <label htmlFor="pwd"><h6>Password:</h6></label>
      <input type='password' name='pwd' value={this.state.password} className="form-control" onChange={(event)=>this.passwordChange(event)} id="pwd"/>
      </div> 
      </form>
      <div className="submitBtn">
              <button className="btn btn-primary" onClick={this.submit}>Submit</button>
              </div>

      
      
      </div> 
    
  
    );
  }
}


export default App;
